package com.rv.harsha.harsharv;

import android.content.Context;
import android.graphics.Movie;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.MainViewHolder> {

    private int NUMBER_OF_ROWS = 10000;
    private int highlightPosition;
    private Context mContext;

    public MainAdapter(Context context) {
        mContext = context;
    }

    public class MainViewHolder extends RecyclerView.ViewHolder {
        public TextView rowTV;
        public LinearLayout rowLL;

        public MainViewHolder(View view) {
            super(view);
            rowTV = view.findViewById(R.id.row_tv);
            rowLL = view.findViewById(R.id.row_ll);
        }
    }

    @Override
    public MainViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.main_list_row, parent, false);

        return new MainViewHolder(itemView);
    }

    public void highlightView(int position){
        highlightPosition = position;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(MainViewHolder holder, int position) {
        holder.rowTV.setText(String.valueOf(position));
        if(position == highlightPosition){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                holder.rowLL.setBackgroundColor(mContext.getColor(R.color.colorAccent));
            }
        }else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                holder.rowLL.setBackgroundColor(mContext.getColor(R.color.colorPrimary));
            }
        }
    }

    @Override
    public int getItemCount() {
        return NUMBER_OF_ROWS;
    }
}